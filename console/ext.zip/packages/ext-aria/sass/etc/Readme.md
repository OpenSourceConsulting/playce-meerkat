# ext-aria/sass/etc

This folder contains miscellaneous SASS files. Unlike `"ext-aria/sass/etc"`, these files
need to be used explicitly.
