Ext.define('Ext.locale.pt_BR.grid.filters.filter.List', {
    override: 'Ext.grid.filters.filter.List',
    loadingText: 'Carregando...'
});
