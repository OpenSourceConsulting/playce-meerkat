// changing the msg text below will affect the LoadMask
Ext.define("Ext.locale.pt_BR.view.AbstractView", {
    override: "Ext.view.AbstractView",
    loadingText: "Carregando..."
});