Ext.define("Ext.locale.pt_BR.tab.Tab", {
    override: "Ext.tab.Tab",
    closeText: "Fechar"
});