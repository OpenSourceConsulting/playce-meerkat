Ext.define('Ext.locale.container.Viewport', {
    override: 'Ext.container.Viewport',
    requires: [
        'Ext.rtl.*'
    ],

    rtl: true
});
