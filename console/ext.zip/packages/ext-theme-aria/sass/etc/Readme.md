# ext-theme-aria/sass/etc

This folder contains miscellaneous SASS files. Unlike `"ext-theme-aria/sass/etc"`, these files
need to be used explicitly.
