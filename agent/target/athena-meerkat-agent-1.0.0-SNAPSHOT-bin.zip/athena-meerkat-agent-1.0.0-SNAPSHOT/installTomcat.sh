#!/bin/bash

export ANT_HOME=/home/meerkat/athena-meerkat-agent-1.0.0-SNAPSHOT/apache-ant-1.9.6

$ANT_HOME/bin/ant install
