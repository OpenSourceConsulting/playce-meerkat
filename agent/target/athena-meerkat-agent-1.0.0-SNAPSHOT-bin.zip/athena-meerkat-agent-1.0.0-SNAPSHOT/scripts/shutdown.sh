#!/bin/bash

. ./env.sh

cd $CATALINA_HOME/bin
./shutdown.sh

