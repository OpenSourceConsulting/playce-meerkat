#!/bin/bash

export AGENT_PROCESS_NAME=Athena_Meerkat_Agent
